<?xml version="1.0"?>
<!--
************************************************************************************************************************************
UserUI.xslt - 将工具栏添加到当前工作区
************************************************************************************************************************************
-->
<xsl:stylesheet version="1.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:frmwrk="Corel Framework Data"
                exclude-result-prefixes="frmwrk">
  <xsl:output method="xml" encoding="UTF-8" indent="yes"/>

  <frmwrk:uiconfig>
    <!-- 引用我们定义的工具栏 -->
    <frmwrk:compositeNode xPath="/uiConfig/commandBars/commandBarData[@guid='TOOLBAR-AI-0000-0000-000000000000']"/>
  </frmwrk:uiconfig>

  <xsl:template match="node()|@*">
    <xsl:copy>
      <xsl:apply-templates select="node()|@*"/>
    </xsl:copy>
  </xsl:template>

</xsl:stylesheet>
