<?xml version="1.0"?>
<!--
************************************************************************************************************************************
AppUI.xslt - 定义 UI 元素 (菜单、工具条、泊坞窗)
************************************************************************************************************************************
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:frmwrk="Corel Framework Data">
  <xsl:output method="xml" encoding="UTF-8" indent="yes"/>
  
  <frmwrk:uiconfig>
    <frmwrk:applicationInfo userConfiguration="true" />
  </frmwrk:uiconfig>

  <xsl:template match="node()|@*">
    <xsl:copy>
      <xsl:apply-templates select="node()|@*"/>
    </xsl:copy>
  </xsl:template>

  <!-- ========================================================================= -->
  <!-- 1. 定义具体的项目 (按钮、WPF控件) -->
  <!-- ========================================================================= -->
  <xsl:template match="uiConfig/items">
    <xsl:copy>
      <xsl:apply-templates select="node()|@*"/>
      
      <!-- 定义按钮 (菜单和工具条共用此按钮) -->
      <!-- 注意：为了让工具条显示图标，请在DLL资源中添加 ID 为此 GUID 的 BMP 图片 -->
      <itemData guid="29D38676-4766-4191-9122-835619375522" 
                noBmpOnMenu="true"
                type="checkButton"
                check="*Docker('D4594611-7393-470F-9311-397223405333')"
                dynamicCategory="2cc24a3e-fe24-4708-9a74-9c75406eebcd"
                userCaption="快捷工具"
                enable="true">
      </itemData>
      
      <!-- 定义 WPF 控件宿主 -->
      <itemData guid="867F0A89-5321-4198-9477-96F9D6C65101"
                type="wpfhost"
                hostedType="Addons\CdrQrDocker\CdrQrDocker.dll,CdrQrDocker.DockerControl"
                enable="true">
      </itemData>
      
      <!-- 工具栏 WPF 控件 -->
      <itemData guid="867F0A89-5321-4198-9477-96F9D6C65102"
                type="wpfhost"
                hostedType="Addons\CdrQrDocker\CdrQrDocker.dll,CdrQrDocker.UI.ToolbarUI"
                enable="true"/>
    </xsl:copy>
  </xsl:template>

  <!-- ========================================================================= -->
  <!-- 2. 定义工具条 -->
  <!-- ========================================================================= -->
  <xsl:template match="uiConfig/commandBars">
    <xsl:copy>
      <xsl:apply-templates select="node()|@*"/>
      
      <!-- AI工具栏 (ToolbarUI) -->
      <commandBarData guid="D4594611-7393-470F-9311-397223405334"
                      nonLocalizableName="CdrAIToolbar"
                      userCaption="悬浮工具栏"
                      locked="false"
                      type="toolbar">
        <toolbar>
          <item guidRef="867F0A89-5321-4198-9477-96F9D6C65102" dock="top"/>
        </toolbar>
      </commandBarData>
    </xsl:copy>
  </xsl:template>

  <!-- ========================================================================= -->
  <!-- 3. 将工具栏添加到主框架布局 -->
  <!-- ========================================================================= -->
  <xsl:template match="uiConfig/containers/container[@guid='bee85f91-3ad9-dc8d-48b5-d2a87c8b2109']/container[@guid='Framework_MainFrame-layout']/dockHost[@guid='894bf987-2ec1-8f83-41d8-68f6797d0db4']/toolbar[@guidRef='c2b44f69-6dec-444e-a37e-5dbf7ff43dae']">
    <xsl:copy-of select="."/>
    <toolbar guidRef="D4594611-7393-470F-9311-397223405334" dock="top" />
  </xsl:template>

  <!-- ========================================================================= -->
  <!-- 4. 定义泊坞窗 -->
  <!-- ========================================================================= -->
  <xsl:template match="uiConfig/dockers">
    <xsl:copy>
      <xsl:apply-templates select="node()|@*"/>
      
      <dockerData guid="D4594611-7393-470F-9311-397223405333"
                  userCaption="快捷工具"
                  wantReturn="true"
                  focusStyle="noThrow">
        <container>
          <item dock="fill" margin="0,0,0,0" guidRef="867F0A89-5321-4198-9477-96F9D6C65101"/>
        </container>
      </dockerData>
    </xsl:copy>
  </xsl:template>

  <!-- ========================================================================= -->
  <!-- 5. 将按钮添加到 窗口 > 泊坞窗 子菜单 -->
  <!-- ========================================================================= -->
  <!-- 匹配泊坞窗菜单 (Dockers menu) -->
  <xsl:template match="uiConfig/commandBars/commandBarData[@guid='3eaa9bbe-28fd-4672-9128-02974ee96332']/menu">
    <xsl:copy>
      <xsl:apply-templates select="node()|@*"/>
      <!-- 在泊坞窗菜单末尾添加我们的按钮 -->
      <item guidRef="29D38676-4766-4191-9122-835619375522"/>
    </xsl:copy>
  </xsl:template>

</xsl:stylesheet>


